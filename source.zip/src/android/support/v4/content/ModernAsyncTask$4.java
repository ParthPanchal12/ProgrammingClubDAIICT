// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.content;


// Referenced classes of package android.support.v4.content:
//            ModernAsyncTask

static class atus
{

    static final int $SwitchMap$android$support$v4$content$ModernAsyncTask$Status[];

    static 
    {
        $SwitchMap$android$support$v4$content$ModernAsyncTask$Status = new int[atus.values().length];
        try
        {
            $SwitchMap$android$support$v4$content$ModernAsyncTask$Status[atus.RUNNING.ordinal()] = 1;
        }
        catch (NoSuchFieldError nosuchfielderror1) { }
        try
        {
            $SwitchMap$android$support$v4$content$ModernAsyncTask$Status[atus.FINISHED.ordinal()] = 2;
        }
        catch (NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
