// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict;

import android.view.View;
import android.widget.AdapterView;

// Referenced classes of package info.androidhive.proclubDaiict:
//            MainActivity

private class <init>
    implements android.widget.nuClickListener
{

    final MainActivity this$0;

    public void onItemClick(AdapterView adapterview, View view, int i, long l)
    {
        MainActivity.access$300(MainActivity.this, i);
    }

    private ()
    {
        this$0 = MainActivity.this;
        super();
    }

    this._cls0(this._cls0 _pcls0)
    {
        this();
    }
}
