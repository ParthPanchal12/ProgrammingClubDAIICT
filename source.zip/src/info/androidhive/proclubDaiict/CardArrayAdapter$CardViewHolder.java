// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict;

import android.widget.TextView;

// Referenced classes of package info.androidhive.proclubDaiict:
//            CardArrayAdapter

static class 
{

    TextView line1;
    TextView line2;

    ()
    {
    }
}
