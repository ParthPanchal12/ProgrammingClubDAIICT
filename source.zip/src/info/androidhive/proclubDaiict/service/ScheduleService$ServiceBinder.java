// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict.service;

import android.os.Binder;

// Referenced classes of package info.androidhive.proclubDaiict.service:
//            ScheduleService

public class this._cls0 extends Binder
{

    final ScheduleService this$0;

    ScheduleService getService()
    {
        return ScheduleService.this;
    }

    public ()
    {
        this$0 = ScheduleService.this;
        super();
    }
}
