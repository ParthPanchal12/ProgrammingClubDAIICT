// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict.service;


public class Blog
{

    private String comment;
    private String content;
    private int id;
    private String tag;
    private String title;
    private String usrername;

    public Blog()
    {
    }

    public String getComment()
    {
        return comment;
    }

    public String getContent()
    {
        return content;
    }

    public int getId()
    {
        return id;
    }

    public String getTag()
    {
        return tag;
    }

    public String getTitle()
    {
        return title;
    }

    public String getUsrername()
    {
        return usrername;
    }

    public void setComment(String s)
    {
        comment = s;
    }

    public void setContent(String s)
    {
        content = s;
    }

    public void setId(int i)
    {
        id = i;
    }

    public void setTag(String s)
    {
        tag = s;
    }

    public void setTitle(String s)
    {
        title = s;
    }

    public void setUsrername(String s)
    {
        usrername = s;
    }
}
