// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict.service;

import android.os.Binder;

// Referenced classes of package info.androidhive.proclubDaiict.service:
//            NotifyService

public class this._cls0 extends Binder
{

    final NotifyService this$0;

    NotifyService getService()
    {
        return NotifyService.this;
    }

    public ()
    {
        this$0 = NotifyService.this;
        super();
    }
}
