// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

public class SecondActivity extends Activity
{

    public SecondActivity()
    {
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030002);
        ((ImageView)findViewById(0x7f0a0006)).setImageResource(0x7f020005);
    }
}
