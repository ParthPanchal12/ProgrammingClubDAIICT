// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.proclubDaiict;


public class Event
{

    private String description;
    private String endTime;
    private String startTime;
    private String title;
    private String url;

    public Event()
    {
    }

    public String getDescription()
    {
        return description;
    }

    public String getEndTime()
    {
        return endTime;
    }

    public String getStartTime()
    {
        return startTime;
    }

    public String getTitle()
    {
        return title;
    }

    public String getUrl()
    {
        return url;
    }

    public void setDescription(String s)
    {
        description = s;
    }

    public void setEndTime(String s)
    {
        endTime = s;
    }

    public void setStartTime(String s)
    {
        startTime = s;
    }

    public void setTitle(String s)
    {
        title = s;
    }

    public void setUrl(String s)
    {
        url = s;
    }
}
