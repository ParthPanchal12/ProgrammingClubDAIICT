// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int card_background = 0x7f020000;
    public static final int card_background_selector = 0x7f020001;
    public static final int card_state_pressed = 0x7f020002;
    public static final int counter_bg = 0x7f020003;
    public static final int download = 0x7f020004;
    public static final int event = 0x7f020005;
    public static final int ic_communities = 0x7f020006;
    public static final int ic_drawer = 0x7f020007;
    public static final int ic_home = 0x7f020008;
    public static final int ic_launcher = 0x7f020009;
    public static final int ic_pages = 0x7f02000a;
    public static final int ic_people = 0x7f02000b;
    public static final int ic_photos = 0x7f02000c;
    public static final int ic_whats_hot = 0x7f02000d;
    public static final int list_item_bg_normal = 0x7f02000e;
    public static final int list_item_bg_pressed = 0x7f02000f;
    public static final int list_selector = 0x7f020010;
    public static final int pattern = 0x7f020011;

    public ()
    {
    }
}
