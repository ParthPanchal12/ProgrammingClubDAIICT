// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int about_layout = 0x7f030000;
    public static final int activity_main = 0x7f030001;
    public static final int activity_second = 0x7f030002;
    public static final int announcement_viewer = 0x7f030003;
    public static final int blog_viewer = 0x7f030004;
    public static final int comment = 0x7f030005;
    public static final int drawer_list_item = 0x7f030006;
    public static final int fragment_categories = 0x7f030007;
    public static final int fragment_find_people = 0x7f030008;
    public static final int fragment_home = 0x7f030009;
    public static final int fragment_pages = 0x7f03000a;
    public static final int fragment_photos = 0x7f03000b;
    public static final int fragment_whats_hot = 0x7f03000c;
    public static final int list_item_card = 0x7f03000d;
    public static final int splash = 0x7f03000e;

    public ()
    {
    }
}
