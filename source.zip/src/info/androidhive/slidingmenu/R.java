// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


public final class R
{
    public static final class array
    {

        public static final int nav_drawer_icons = 0x7f060000;
        public static final int nav_drawer_items = 0x7f060001;

        public array()
        {
        }
    }

    public static final class attr
    {

        public attr()
        {
        }
    }

    public static final class color
    {

        public static final int counter_text_bg = 0x7f070000;
        public static final int counter_text_color = 0x7f070001;
        public static final int list_background = 0x7f070002;
        public static final int list_background_pressed = 0x7f070003;
        public static final int list_divider = 0x7f070004;
        public static final int list_item_title = 0x7f070005;

        public color()
        {
        }
    }

    public static final class dimen
    {

        public static final int activity_horizontal_margin = 0x7f040000;
        public static final int activity_vertical_margin = 0x7f040001;

        public dimen()
        {
        }
    }

    public static final class drawable
    {

        public static final int card_background = 0x7f020000;
        public static final int card_background_selector = 0x7f020001;
        public static final int card_state_pressed = 0x7f020002;
        public static final int counter_bg = 0x7f020003;
        public static final int download = 0x7f020004;
        public static final int event = 0x7f020005;
        public static final int ic_communities = 0x7f020006;
        public static final int ic_drawer = 0x7f020007;
        public static final int ic_home = 0x7f020008;
        public static final int ic_launcher = 0x7f020009;
        public static final int ic_pages = 0x7f02000a;
        public static final int ic_people = 0x7f02000b;
        public static final int ic_photos = 0x7f02000c;
        public static final int ic_whats_hot = 0x7f02000d;
        public static final int list_item_bg_normal = 0x7f02000e;
        public static final int list_item_bg_pressed = 0x7f02000f;
        public static final int list_selector = 0x7f020010;
        public static final int pattern = 0x7f020011;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int about = 0x7f0a0018;
        public static final int aboutApp = 0x7f0a0000;
        public static final int aboutDev = 0x7f0a0001;
        public static final int aboutDev1 = 0x7f0a0002;
        public static final int action_settings = 0x7f0a0017;
        public static final int card_listView = 0x7f0a0013;
        public static final int card_listViewCategory = 0x7f0a0011;
        public static final int codingImage = 0x7f0a0006;
        public static final int counter = 0x7f0a0010;
        public static final int drawer_layout = 0x7f0a0003;
        public static final int frame_container = 0x7f0a0004;
        public static final int icon = 0x7f0a000e;
        public static final int line1 = 0x7f0a0015;
        public static final int line2 = 0x7f0a0016;
        public static final int list = 0x7f0a0012;
        public static final int listOfComment = 0x7f0a000d;
        public static final int list_comment = 0x7f0a000c;
        public static final int list_slidermenu = 0x7f0a0005;
        public static final int textView1 = 0x7f0a0009;
        public static final int textView2 = 0x7f0a000a;
        public static final int textView3 = 0x7f0a000b;
        public static final int textViewAnn1 = 0x7f0a0007;
        public static final int textViewAnn2 = 0x7f0a0008;
        public static final int title = 0x7f0a000f;
        public static final int txtLabel = 0x7f0a0014;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int about_layout = 0x7f030000;
        public static final int activity_main = 0x7f030001;
        public static final int activity_second = 0x7f030002;
        public static final int announcement_viewer = 0x7f030003;
        public static final int blog_viewer = 0x7f030004;
        public static final int comment = 0x7f030005;
        public static final int drawer_list_item = 0x7f030006;
        public static final int fragment_categories = 0x7f030007;
        public static final int fragment_find_people = 0x7f030008;
        public static final int fragment_home = 0x7f030009;
        public static final int fragment_pages = 0x7f03000a;
        public static final int fragment_photos = 0x7f03000b;
        public static final int fragment_whats_hot = 0x7f03000c;
        public static final int list_item_card = 0x7f03000d;
        public static final int splash = 0x7f03000e;

        public layout()
        {
        }
    }

    public static final class menu
    {

        public static final int main = 0x7f090000;

        public menu()
        {
        }
    }

    public static final class string
    {

        public static final int action_settings = 0x7f080000;
        public static final int app_name = 0x7f080001;
        public static final int desc_list_item_icon = 0x7f080002;
        public static final int drawer_close = 0x7f080003;
        public static final int drawer_open = 0x7f080004;
        public static final int hello_world = 0x7f080005;

        public string()
        {
        }
    }

    public static final class style
    {

        public static final int AppBaseTheme = 0x7f050000;
        public static final int AppTheme = 0x7f050001;
        public static final int Theme_Splash = 0x7f050002;

        public style()
        {
        }
    }


    public R()
    {
    }
}
