// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int about = 0x7f0a0018;
    public static final int aboutApp = 0x7f0a0000;
    public static final int aboutDev = 0x7f0a0001;
    public static final int aboutDev1 = 0x7f0a0002;
    public static final int action_settings = 0x7f0a0017;
    public static final int card_listView = 0x7f0a0013;
    public static final int card_listViewCategory = 0x7f0a0011;
    public static final int codingImage = 0x7f0a0006;
    public static final int counter = 0x7f0a0010;
    public static final int drawer_layout = 0x7f0a0003;
    public static final int frame_container = 0x7f0a0004;
    public static final int icon = 0x7f0a000e;
    public static final int line1 = 0x7f0a0015;
    public static final int line2 = 0x7f0a0016;
    public static final int list = 0x7f0a0012;
    public static final int listOfComment = 0x7f0a000d;
    public static final int list_comment = 0x7f0a000c;
    public static final int list_slidermenu = 0x7f0a0005;
    public static final int textView1 = 0x7f0a0009;
    public static final int textView2 = 0x7f0a000a;
    public static final int textView3 = 0x7f0a000b;
    public static final int textViewAnn1 = 0x7f0a0007;
    public static final int textViewAnn2 = 0x7f0a0008;
    public static final int title = 0x7f0a000f;
    public static final int txtLabel = 0x7f0a0014;

    public ()
    {
    }
}
