// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int activity_horizontal_margin = 0x7f040000;
    public static final int activity_vertical_margin = 0x7f040001;

    public ()
    {
    }
}
