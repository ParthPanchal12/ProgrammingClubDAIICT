// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int counter_text_bg = 0x7f070000;
    public static final int counter_text_color = 0x7f070001;
    public static final int list_background = 0x7f070002;
    public static final int list_background_pressed = 0x7f070003;
    public static final int list_divider = 0x7f070004;
    public static final int list_item_title = 0x7f070005;

    public ()
    {
    }
}
