// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package info.androidhive.slidingmenu;


// Referenced classes of package info.androidhive.slidingmenu:
//            R

public static final class 
{

    public static final int action_settings = 0x7f080000;
    public static final int app_name = 0x7f080001;
    public static final int desc_list_item_icon = 0x7f080002;
    public static final int drawer_close = 0x7f080003;
    public static final int drawer_open = 0x7f080004;
    public static final int hello_world = 0x7f080005;

    public ()
    {
    }
}
