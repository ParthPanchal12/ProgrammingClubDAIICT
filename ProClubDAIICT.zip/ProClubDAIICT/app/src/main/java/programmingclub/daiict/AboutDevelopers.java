package programmingclub.daiict;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by spock on 1/8/15.
 */
public class AboutDevelopers extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_developers);
    }
}
