package programmingclub.daiict;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

/**
 * Created by spock on 31/7/15.
 */
public class MainActivity extends Activity {

    ImageView blog;
    ImageView announcement;
    ImageView events;
    ImageView categories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
        blog = (ImageView) findViewById(R.id.blogs);
        blog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("programmingclub.daiict.BLOGLISTVIEW");
                startActivity(i);

            }
        });
        announcement = (ImageView) findViewById(R.id.announcement);
        announcement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent("programmingclub.daiict.ANNOUNCEMENTLISTVIEW");
                startActivity(i);


            }
        });
        events = (ImageView) findViewById(R.id.event);
        events.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("programmingclub.daiict.EVENTLISTVIEW");
                startActivity(i);


            }
        });
        categories = (ImageView) findViewById(R.id.category);
        categories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent("programmingclub.daiict.CATEGORYLISTVIEW");
                startActivity(i);


            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_blog_list_view, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // toggle nav drawer on selecting action bar app icon/title
        // Handle action bar actions click
        switch (item.getItemId()) {
            case R.id.about:
            {
                Intent in=new Intent("programmingclub.daiict.ABOUTDEVELOPER");
                startActivity(in);
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}